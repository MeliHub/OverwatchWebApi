package com.reidius.lawrenceafriyie.overwatchmap.models;

public class IncidentHistory {
}
