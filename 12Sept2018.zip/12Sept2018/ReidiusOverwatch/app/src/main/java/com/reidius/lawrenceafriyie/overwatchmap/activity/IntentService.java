package com.reidius.lawrenceafriyie.overwatchmap.activity;

public class IntentService {
}
